# /// script
# dependencies = [
#   "pygame-ce",
# ]
# ///

import pygame as pg
import asyncio
import random
import math
import sys

GRID_ROWS = 3
GRID_COLS = 6
GRID_X = 75
GRID_Y = 55
TILE_SIZE = 48
SNOWMAN_COST = 100

WEB = False
if sys.platform in ["wasi", "emscripten"]:
    WEB = True
    from platform import window
    window.canvas.style.imageRendering = "pixelated"

async def main():
    pg.init()
    font = pg.font.Font(None, 14)
    bigfont = pg.font.Font(None, 24)
    if WEB:
        screen = pg.display.set_mode((400, 240))
    else:
        screen = pg.display.set_mode((400, 240), pg.SCALED)
    clock = pg.Clock()
    backgrounds, player_sprites, sounds, enemy_sprites, songs = get_assets()

    player = Player()
    phase = GamePhase()
    snowfall = Snowfall()
    enemies = []
    coins = []
    coin_counter = [0]
    n_snowman = 0
    phase.state = "PAUSE"
    start_txt = "Start Game"
    msg = "Noo! the Spring creatures are coming, \nhelp defending the last days of Winter!"
    random_snow_pos = []
    for i in range(120):
        color = [random.randint(245, 255),random.randint(245, 255),random.randint(250, 255)]
        random_snow_pos.append((random.randint(0, TILE_SIZE),
                               random.randint(0, TILE_SIZE),
                               random.randint(1, 4),
                               color))
    fade = Fade((400,240))
    fade.start()
    songs["current"]=songs["song1"]
    songs["current"].play(-1)

    running = True

    while running:
        buttons = []
        dt = clock.tick() / 1000
        player.update(dt, phase.grid, phase.state, sounds)
        fade.update(dt)
        if not phase.state == "ATTACK" or len(enemies) == 0:
            phase.update(dt, sounds, songs, fade)
        if phase.spawn_wave:
            spawn_wave(enemies, phase.wave)
            phase.spawn_wave = False

        screen.blit(backgrounds[max(0,phase.wave)], (0, 0))
        tile_pos = pos_to_tile(player.pos.x, player.pos.y)

        build_button_rect = None

        if phase.state == "PAUSE":
            if phase.wave == 0: snowfall.make_snow()
            def start_game():
                phase.reset()
                player.reset()
                if WEB:
                    window.eval('document.querySelector("canvas").requestFullscreen()')

            buttons.append(Button((len(buttons) * 70 + 150, 100, 125, 40), start_txt, start_game, (50, 200, 100)))

        elif tile_pos and phase.state != "ATTACK":
            r, c = tile_pos
            tile = phase.grid[r][c]

            if tile.snowman is None and player.snow >= SNOWMAN_COST + 50 and n_snowman < phase.wave+1:

                def build():
                    tile.snowman = Snowman(r, c)
                    player.snow -= SNOWMAN_COST

                buttons.append(Button((len(buttons) * 70 + 150, 5, 65, 20), "+ Snowman", build))
            elif tile.snowman:
                if tile.snowman.hp < 70 and player.snow >= SNOWMAN_COST // 2 + 50 :

                    def repair():
                        tile.snowman.hp += 30
                        player.snow -= SNOWMAN_COST // 2

                    buttons.append(Button((len(buttons) * 70 + 150, 5, 65, 20), "Repair", repair))
                if tile.snowman.range == 1 and coin_counter[0] >= 3:

                    def up_range():
                        tile.snowman.range = 1.5
                        coin_counter[0] -= 3

                    buttons.append(Button((len(buttons) * 70 + 150, 5, 65, 20), "+ Range", up_range, (50, 200, 100)))

                if tile.snowman.resistance == 1 and coin_counter[0] >= 4:

                    def up_resist():
                        tile.snowman.resistance = 2
                        coin_counter[0] -= 4

                    buttons.append(Button((len(buttons) * 70 + 150, 5, 65, 20), "+ Resist", up_resist, (50, 200, 100)))

                if tile.snowman.damage == 1 and coin_counter[0] >= 5:

                    def up_damage():
                        tile.snowman.damage = 2
                        coin_counter[0] -= 5

                    buttons.append(Button((len(buttons) * 70 + 150, 5, 65, 20), "+ Damage", up_damage, (50, 200, 100)))

        p_mouse = pg.mouse.get_pos()
        for event in pg.event.get():
            if event.type == pg.QUIT:
                running = False
            if event.type == pg.MOUSEBUTTONDOWN:
                for b in buttons:
                    if b.click(event.pos):
                        sounds["upgrade"].play()
                        p_mouse = [0,0]
                        break

                if phase.state == "ATTACK" and player.cooldown < 0:
                    player.cooldown = 0.5
                    player.throw(p_mouse)
                    sounds["trow"].play()

                elif not phase.state in ("PAUSE", "ATTACK") and pos_to_tile(*p_mouse):
                    player.move_to(p_mouse)

        if phase.state == "RETREAT":
            player.move_to((40, 130))


        n_snowman = 0
        for r in range(GRID_ROWS):
            for c in range(GRID_COLS):
                tile = phase.grid[r][c]
                #img = snow_tiles[int(tile.snow)]
                #if phase.state != "PAUSE":
                    #img = snow_tiles[0]
                for snow in range(int(tile.snow)*20):
                    position = (random_snow_pos[snow][0] + GRID_X + c * TILE_SIZE,
                                random_snow_pos[snow][1] + GRID_Y + r * TILE_SIZE)
                    pg.draw.circle(screen, random_snow_pos[snow][3], position, random_snow_pos[snow][2])

                    #screen.blit(img, (GRID_X + c * TILE_SIZE, GRID_Y + r * TILE_SIZE))

                if tile.snowman:
                    tile.snowman.draw(screen, font)
                    tile.snowman.cooldown -= dt
                    n_snowman +=1

        for enemy in enemies:
            enemy.update(dt, player, phase.grid)
            enemy.draw(screen, enemy_sprites)
            for ball in player.snowballs:
                if (enemy.pos - ball.pos).length() < enemy.radius + ball.radius:
                    enemy.hit(coins)
                    sounds["hurt"][random.randint(0,1)].play()
                    if player.snow < 50 or random.random() > 0.5:
                        enemy.hit(coins)
                    ball.dead = True
            for r in range(GRID_ROWS):
                for c in range(GRID_COLS):
                    snowman = phase.grid[r][c].snowman
                    if snowman and (enemy.pos - snowman.world_pos()).length() < 35 * snowman.range and snowman.cooldown <= 0:
                        enemy.hit(coins)
                        if snowman.damage > 1:
                            enemy.hit(coins)
                        sounds["hurt"][random.randint(0,1)].play()
                        snowman.cooldown = 0.5
                        enemy.target = snowman
            if enemy.dead:
                enemy.melt_tile(phase.grid)

        enemies = [s for s in enemies if not s.dead]
        

        coins = [c for c in coins if not c.dead]

        if player.snow < 0:
            phase.state = "PAUSE"
            if phase.wave == 9:
                player.snow = 1
                phase.grid = [[Tile(0) for _ in range(GRID_COLS)] for _ in range(GRID_ROWS)]
            if phase.timer < 0:
                sounds["over"][random.randint(0,1)].play()
                phase.wave = min(9, phase.wave+1)
                phase.timer = 0.5
            coins, enemies = [],[]
            msg = "Oh well, Winter was cut short.\nSpring is coming early this year..."
            start_txt = "Try again"
            asyncio.sleep(0.5)
        elif phase.wave == 9 and phase.state != "PAUSE" and len(enemies) == 0:
            sounds["levelup"].play()
            phase.state = "PAUSE"
            phase.grid = [[Tile(0) for _ in range(GRID_COLS)] for _ in range(GRID_ROWS)]
            coins = []
            msg = "You did it, Winter was fun until the end!\n       And Spring will be great too!"
            start_txt = "Play again"
            asyncio.sleep(0.5)
        player.draw(screen, player_sprites, phase.state)
        

        draw_snow_pile(screen, player.snow // 10, GRID_X - 25, 152)

        snowfall.make_snow(phase.wave)
        snowfall.update(dt, phase.grid)
        snowfall.draw(screen)
        for coin in coins:
            coin.draw(screen)
            coin.update(dt, coin_counter, sounds)

        fps = font.render(str(int(clock.get_fps())), 0, (255, 255, 0))
        screen.blit(fps, (10, 10))
        #screen.blit(font.render(str(phase.state), 0, (255, 255, 0)), (50, 10))
        #screen.blit(font.render(str(int(phase.timer)), 0, (255, 255, 0)), (150, 10))
        for b in buttons:
            b.draw(screen, bigfont if phase.state == "PAUSE" else font)
        if phase.state == "PAUSE":
            screen.blit(bigfont.render(msg, 0, (255, 255, 255), (100, 100, 120)), (80, 160))
        draw_coin_counter(screen, font, coin_counter[0])
        pg.draw.circle(screen, (phase.state=="ATTACK", 100, 100), p_mouse, 5)
        fade.draw(screen)
        pg.display.flip()

        await asyncio.sleep(0)

def spawn_wave(enemies, wave):

    for _ in range(2 + wave):

        x = random.randint(400,510)
        y = random.randint(-100, 400)

        enemies.append(Enemy(x, y, 0, wave))
    enemies.append(Enemy(750, 150, 1, wave))


def pos_to_tile(x, y):

    col = int((x - GRID_X) // TILE_SIZE)
    row = int((y - GRID_Y) // TILE_SIZE)

    if 0 <= row < GRID_ROWS and 0 <= col < GRID_COLS:
        return row, col

    return None


def get_assets():
    for i in range(5):
        all_bg = pg.image.load("assets/all_bg.jpg")
    all_bg.convert()
    backgrounds = []
    for i in range(5):
        backgrounds.append(all_bg.subsurface((0, i*240, 400, 240)))
        backgrounds.append(all_bg.subsurface((400, i*240, 400, 240)))
        #backgrounds.append(pg.image.load(f"background{i}.jpg"))
        #backgrounds[-1].convert()

    player_sheet = pg.image.load("assets/player.png")
    player_sheet.set_colorkey((255,0, 255))
    player_sprites = {"idle": [], "running": [], "trowing": []}
    for i in range(4):
        player_sprites["running"].append(player_sheet.subsurface((i*42, 0, 42, 45)))
        player_sprites["trowing"].append(player_sheet.subsurface((i*42, 45, 42, 44)))
    player_sprites["idle"].append(player_sheet.subsurface((3*42, 44, 42, 45)))
    player_sprites["idle"].append(player_sheet.subsurface((2*42, 44, 42, 45)))
    player_sprites["idle"].append(player_sheet.subsurface((0*42, 44, 42, 45)))

    enemy_sprites = []
    enemy_sheet = pg.image.load("assets/enemies.png")
    enemy_sheet.set_colorkey((0,0, 255))
    for row in range(5):
        enemy_sprites.append([])
        for col in range(3):
            enemy_sprites[row].append(enemy_sheet.subsurface((col*48, row*38, 48, 38)))


    sounds = {}
    sounds["steps"] = [pg.mixer.Sound("assets/step.ogg"),
                        pg.mixer.Sound("assets/step2.ogg")]
    sounds["hurt"] = [pg.mixer.Sound("assets/hurt.ogg"),
                        pg.mixer.Sound("assets/hurt2.ogg")]
    sounds["over"] = [pg.mixer.Sound("assets/over.ogg"),
                        pg.mixer.Sound("assets/over2.ogg")]
    sounds["levelup"] = pg.mixer.Sound("assets/levelup.ogg")
    sounds["upgrade"] = pg.mixer.Sound("assets/upgrade.ogg")
    sounds["coin"] = pg.mixer.Sound("assets/coin.ogg")
    sounds["trow"] = pg.mixer.Sound("assets/trow.ogg")
    songs = {}
    songs["song1"] = pg.mixer.Sound("assets/song1.ogg")
    songs["song2"] = pg.mixer.Sound("assets/song2.ogg")
    songs["song3"] = pg.mixer.Sound("assets/song3.ogg")
    songs["current"] = songs["song1"]

    return backgrounds, player_sprites, sounds, enemy_sprites, songs


class Tile:
    def __init__(self, snow):
        self.snow = snow  # 0–4 snow levels
        self.snowman = None  # placed snowman


class Snowball:
    def __init__(self, x, y, target):
        self.delay = 0.25

        self.pos = pg.Vector2(x, y)

        direction = pg.Vector2(target) - self.pos
        direction.normalize_ip()

        self.vel = direction * 400
        self.radius = random.randint(3,4)
        self.dead = False

    def update(self, dt):
        if self.delay > 0:
            self.delay -= dt 
            return

        self.pos += self.vel * dt

        if self.pos.x > 400 or self.pos.y < 0 or self.pos.y > 240:
            self.dead = True

    def draw(self, screen):
        if self.delay < 0:
            pg.draw.circle(screen, (255, 255, 255), self.pos, self.radius)


class Player:
    def __init__(self, x=40, y=120):
        self.reset(x, y)

    def reset(self, x=40, y=120):
        self.pos = pg.Vector2(x, y)
        self.target = pg.Vector2(x, y)

        self.speed = 90
        self.radius = 10

        self.snow = 0

        self.snowballs = []
        self.cooldown = 0.5
        self.timer = 0
        self.flip = 0
        self.state = "idle"
        self.steps = 0.1

    def move_to(self, pos):
        self.target = pg.Vector2(pos)

    def throw(self, pos):
        if self.snow <= 0:
            return
        self.snow -= 1
        self.snowballs.append(Snowball(self.pos.x, self.pos.y-22, pos))

    def update(self, dt, grid, phase_state, sounds):
        self.state = "idle"
        if phase_state == "ATTACK":
            self.flip = 0
            if self.cooldown > 0:
                self.state = "trowing"
        # movement
        direction = self.target - self.pos
        dist = direction.length()
        
        if dist > 2:
            self.state = "running"
            direction.normalize_ip()
            self.flip = (direction.x < 0)
            self.pos += direction * self.speed * dt
            if self.steps < 0:
                sounds["steps"][random.randint(0,1)].play()
                self.steps = random.uniform(0.4,0.6)
        # snowballs
        for b in self.snowballs:
            b.update(dt)

        self.snowballs = [b for b in self.snowballs if not b.dead]

        self.cooldown -= dt
        self.timer += dt
        self.steps -= dt

        tile = pos_to_tile(self.pos.x, self.pos.y)
        if tile and grid[tile[0]][tile[1]].snow > 1 and self.cooldown < 0 and self.snow < 300:
            grid[tile[0]][tile[1]].snow -= 1
            self.snow += 7 * grid[tile[0]][tile[1]].snow
            self.cooldown = 0.5

    def draw(self, screen, player_sprites, phase_state):

        #pg.draw.circle(screen, (200, 60, 60), self.pos, self.radius)
        if self.state == "idle":
            sprite_index = (self.timer*2)%2 #+ (phase_state == "ATTACK")
        elif self.state == "running":
            sprite_index = (self.timer*5)%4
        elif self.state == "trowing":
            sprite_index = (-self.cooldown*4)%2#+1
        sprite = player_sprites[self.state][int(sprite_index)]
        if self.flip:
            sprite = pg.transform.flip(sprite, 1, 0)
        screen.blit(sprite, self.pos + (-22,-44))

        for b in self.snowballs:
            b.draw(screen)


class GamePhase:

    def __init__(self):
        self.reset()

    def reset(self):
        self.state = "COLLECT"
        self.timer = 10
        self.spawn_wave = False
        self.grid = [[Tile(random.randint(1, 3)) for _ in range(GRID_COLS)] for _ in range(GRID_ROWS)]
        self.wave = -1

    def update(self, dt, sounds, songs, fade):
        self.timer -= dt

        if self.timer <= 0:

            if self.state == "COLLECT":
                self.state = "RETREAT"
                self.timer = 2
                songs["current"].stop()
                songs["current"]=songs["song3"]
                songs["current"].play(-1)

            elif self.state == "RETREAT":
                self.state = "ATTACK"
                self.timer = 1
                self.spawn_wave = True

            elif self.state == "ATTACK":
                fade.start()
                self.timer = 1
                songs["current"].stop()
                songs["current"]=songs[f"song{random.randint(1,2)}"]
                songs["current"].play(-1)
                self.state = "DELAY"

            elif self.state == "DELAY":
                sounds["levelup"].play()
                self.state = "COLLECT"
                self.wave += 1
                self.timer = 10

class SnowParticle:

    def __init__(self):
        self.x = random.randint(0, 400)
        self.y = random.randint(-250, 0)

        self.speed = random.uniform(30, 80)
        self.size = random.randint(1, 3)

        self.ground = random.uniform(25, 240)

        self.resting = False
        self.dead = False

    def update(self, dt, grid):

        if not self.resting:

            self.y += self.speed * dt
            self.x += math.sin(self.y * 0.02) * 10 * dt

            if self.y >= self.ground:
                self.y = self.ground
                self.resting = True
                tile = pos_to_tile(self.x, self.y)
                if tile:
                    r, c = tile
                    grid[r][c].snow = min(4, grid[r][c].snow + self.size / 100)

        else:
            self.size -= dt
            if self.size < 0.5:
                self.dead = True

    def draw(self, screen):
        size = self.size
        if not self.resting:
            size += random.random() * 2 - 1
        pg.draw.circle(screen, (255, 255, 255), (int(self.x), int(self.y)), size)


class Snowfall:

    def __init__(self):
        self.particles = []

    def update(self, dt, grid):

        for p in self.particles:
            p.update(dt, grid)
        self.particles = [p for p in self.particles if not p.dead]

    def make_snow(self, wave=0):
        if len(self.particles) < 999-wave*150:
            for _ in range(4):
                self.particles.append(SnowParticle())

    def draw(self, screen):
        for p in self.particles:
            p.draw(screen)


def draw_snow_pile(screen, snow, x, y, rows=7, spacing=5):

    placed = 0

    for row in range(rows, 0, -1):

        row_width = (row - 1) * spacing
        start_x = x - row_width / 2
        py = y - (rows - row) * spacing

        for i in range(row):

            if placed >= snow:
                return

            px = start_x + i * spacing + placed % 7 // 3

            pg.draw.circle(screen, (240, 240, 255), (int(px), int(py)), spacing/2 + 1 + placed % 5 // 3)

            placed += 1


class Enemy:

    def __init__(self, x, y, boss=0, level=0):
        self.pos = pg.Vector2(x, y)
        self.radius = level//3 + random.uniform(5, 10) + boss * 5
        self.hp = 1 + level//2 + boss * 5 + random.uniform(1, 3)
        self.dead = False
        self.offset = pg.Vector2(15, random.randint(-5, 5))
        self.cooldown = 0
        self.target = None
        self.type = random.randint(boss*level//2,level//2+1)%5
        self.timer = 0
        self.speed = (self.type+1)*10 + level * 2 + random.uniform(10, 30)

    def update(self, dt, player, grid):

        if self.target is None:
            target_pos = player.pos + self.offset
        else:
            target_pos = self.target.world_pos() + self.offset

        direction = target_pos - self.pos
        dist = direction.length()
        self.cooldown -= dt
        self.timer += dt

        if dist > 1:
            direction.normalize_ip()
            self.pos += direction * self.speed * dt

        if self.target:

            pos = self.target.world_pos() + self.offset

            if (self.pos - pos).length() < 30 and self.cooldown <= 0:
                self.offset = pg.Vector2(15, random.randint(-5, 5))
                self.target.hp -= self.type*self.radius/self.target.resistance/2
                self.cooldown = 0.5

                r, c = self.target.r, self.target.c
                tile = grid[r][c]

                if self.target.hp <= 0:
                    tile.snowman = None
                    self.target = None

        elif self.target is None and dist < 30:
            player.snow -= 10*self.type*self.radius/2
            self.dead = True

    def hit(self, coins):
        self.hp -= 1
        if random.random() < 0.2:
            coins.append(Coin(self.pos.x, self.pos.y))
        if self.hp <= 0:
            self.dead = True

    def melt_tile(self, grid):

        tile = pos_to_tile(self.pos.x, self.pos.y)

        if tile:
            r, c = tile
            grid[r][c].snow = max(0, grid[r][c].snow - 1)

    def draw(self, screen, enemy_sprites):

        #pg.draw.circle(screen, (50, 200, 80), (int(self.pos.x), int(self.pos.y)), self.radius)
        sprite = enemy_sprites[self.type][int(self.timer*4%3)]
        scaled = pg.transform.scale_by(sprite, self.radius/10)
        rect = scaled.get_rect()
        rect.center = self.pos
        screen.blit(scaled, rect)


class Snowman:
    def __init__(self, r, c):
        self.r = r
        self.c = c
        self.cooldown = -1
        self.hp = 100
        self.range = 1
        self.damage = 1
        self.resistance = 1
        self.arm_pos = self.world_pos() + (random.randint(-15,5), random.randint(-5,0))

    def world_pos(self):
        x = GRID_X + self.c * TILE_SIZE + TILE_SIZE // 2
        y = GRID_Y + self.r * TILE_SIZE + TILE_SIZE // 2
        return pg.Vector2(x, y)

    def draw(self, screen, font):
        pos = self.world_pos()
        size = self.hp // 20
        pg.draw.circle(screen, (235, 235, 245), pos + (0, 10 - size), 11 + size // 2)  # body
        pg.draw.circle(screen, (225, 225, 245), pos + (0, -5 - size), 7 + size // 4)  # head
        if self.resistance > 1:  # scarf
            pg.draw.line(screen, (255, 50, 100), pos + (-7, -2 - size), pos + (7, -size), 4)
            pg.draw.line(screen, (220, 40, 80), pos + (10, 15 - size), pos + (7, -size), 5)

        pg.draw.circle(screen, (0, 0, 0), pos + (4, -9 - size), 1)  # eye
        pg.draw.polygon(screen, (255, 150, 0), [pos + (6, -7 - size), pos + (12, -5 - size), pos + (6, -5 - size)])  # nose
        end_pos = self.arm_pos + (20 * self.range, -5)
        if self.cooldown < 0.2:
            end_pos = self.arm_pos + (10 * self.range, -5)
        pg.draw.line(screen, (100, 50, 0), pos, end_pos, 3)  # arm

        if self.damage > 1:  # hat
            pg.draw.line(screen, (50, 50, 50), pos + (-8, -13 - size), pos + (10, -15 - size), 3)
            pg.draw.line(screen, (0, 0, 0), pos + (0, -15 - size), pos + (0, -23 - size), 10)

        #txt = font.render(str(size * 2), 0, (255, 255, 255))
        #screen.blit(txt, pos + (-5, -30))


class Button:

    def __init__(self, rect, text, callback, color=(80, 120, 200)):
        self.rect = pg.Rect(rect)
        self.text = text
        self.callback = callback
        self.color = color

    def draw(self, screen, font):

        mouse = pg.mouse.get_pos()

        color = self.color
        if self.rect.collidepoint(mouse):
            color = (110, 150, 230)

        pg.draw.rect(screen, color, self.rect, border_radius=3)
        pg.draw.rect(screen, (20, 20, 40), self.rect, 2, 3)

        txt = font.render(self.text, 0, (255, 255, 255))
        screen.blit(txt, txt.get_rect(center=self.rect.center))

    def click(self, pos):

        if self.rect.collidepoint(pos):
            self.callback()
            return True

        return False


class Coin:

    def __init__(self, x, y):
        self.pos = pg.Vector2(x, y)
        self.vel = pg.Vector2(random.uniform(-40, 40), random.uniform(-80, -40))

        self.radius = 7
        self.target = pg.Vector2(20, 152)

        self.speed = 260
        self.dead = False

        self.float_time = 0.4

    def update(self, dt, counter, sounds):

        if self.float_time > 0:
            self.float_time -= dt
            self.pos += self.vel * dt
            return

        direction = self.target - self.pos
        dist = direction.length()

        if dist < 5:
            counter[0] += 1
            self.dead = True
            sounds["coin"].play()
            return

        direction.normalize_ip()
        self.pos += direction * self.speed * dt

    def draw(self, screen):
        pg.draw.circle(screen, (240, 200, 40), self.pos, self.radius)
        pg.draw.circle(screen, (200, 160, 20), self.pos, self.radius, 2)


def draw_coin_counter(screen, font, value):
    pos = (20, 152)

    if value > 0:
        pg.draw.circle(screen, (255, 220, 70), pos, 10)
        pg.draw.circle(screen, (220, 180, 40), pos, 10, 2)

        text = font.render(str(value), 0, (200, 160, 30))
        screen.blit(text, text.get_rect(center=pos))

class Fade:

    def __init__(self, size, speed=255):
        self.surface = pg.Surface(size)
        self.surface.fill((0,0,0))

        self.alpha = 0
        self.speed = speed

        self.state = "idle"

    def start(self):
        self.state = "fade_out"

    def update(self, dt):

        if self.state == "fade_out":
            self.alpha += self.speed * dt

            if self.alpha >= 255:
                self.alpha = 255
                self.state = "fade_in"

        elif self.state == "fade_in":
            self.alpha -= self.speed * dt

            if self.alpha <= 0:
                self.alpha = 0
                self.state = "idle"

    def draw(self, screen):
        if self.alpha > 0:
            self.surface.set_alpha(int(self.alpha))
            screen.blit(self.surface, (0,0))

asyncio.run(main())
